wget -O /tmp/assistant "$1/dispatch/static/reminder.tar.gz"
echo 'tar.gz пакет ТЕЗИС:Оповещения успешно скачан'
