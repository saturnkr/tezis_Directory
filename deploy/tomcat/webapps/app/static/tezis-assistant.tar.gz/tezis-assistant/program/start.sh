#!/bin/bash
java -Xmx110m -XX:+UseCodeCacheFlushing -XX:MaxPermSize=42m -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5005 -jar ./assistant.jar
