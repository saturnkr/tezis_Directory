--$Id: 130516-1718-updateTableDocExtraField.sql 9670 2013-05-16 15:27:23Z panasyuk $
-- Description:
ALTER TABLE df_doc_extra_field ALTER COLUMN field_value varchar(1000)^