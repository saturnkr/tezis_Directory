-- $Id$
-- Description:

update df_doc_kind  SET use_all_procs  = 1 where use_all_procs is null;