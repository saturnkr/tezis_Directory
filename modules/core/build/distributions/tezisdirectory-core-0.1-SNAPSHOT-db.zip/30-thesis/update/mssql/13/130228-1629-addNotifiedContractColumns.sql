--$Id$
--$Description:

alter table DF_CONTRACT add NOTIFIED_CREATOR tinyint;
alter table DF_CONTRACT add NOTIFIED_OWNER tinyint;