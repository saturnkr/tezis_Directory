--$Id: 130426-1343-addColumnUploadFromCdr.sql 9406 2013-04-26 14:21:30Z kozyaikin $
--$Description:
alter table DF_BANK add UPLOAD_FROM_CBR tinyint^
alter table df_bank_region add UPLOAD_FROM_CBR tinyint^
