-- $Id$
-- Description:

delete FROM sec_permission WHERE role_id  = '96fa7fe9-397d-4bac-b14a-eec2d94de68c' and target = 'df$Organization.browse';