-- $Id$
-- Description:

update SEC_CONSTRAINT set ENTITY_NAME = 'tm$UserGroup' where ENTITY_NAME = 'wf$UserGroup';