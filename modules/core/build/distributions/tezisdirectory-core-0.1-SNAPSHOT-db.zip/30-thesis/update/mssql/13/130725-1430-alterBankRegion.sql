--$Id$
--$Description:

alter table DF_BANK_REGION alter column CODE varchar(9)^