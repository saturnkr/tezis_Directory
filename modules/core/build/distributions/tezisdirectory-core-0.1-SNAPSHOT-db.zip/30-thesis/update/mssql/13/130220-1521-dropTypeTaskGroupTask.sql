-- $Id$
-- Description:

alter table TM_TASK_GROUP_TASK drop column type;