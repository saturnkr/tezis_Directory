--$Id$
--$Description:

alter table DF_ORGANIZATION alter column INN varchar(12)^