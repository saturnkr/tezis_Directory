--$Id: 130603-1206-alterContarct.sql 10062 2013-06-03 08:21:49Z kozyaikin $
--Description:
alter table DF_CONTRACT alter column PAYMENT_CONDITIONS varchar(max)^