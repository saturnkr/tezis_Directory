-- $Id: 130821-1131-thesisCardAttachment.sql 12498 2013-10-14 07:46:44Z gorbunkov $
alter table WF_ATTACHMENT add PORTAL_PUBLISH_STATE varchar(5);