--$Id: 130405-1515-addColunmShortNameToBank.sql 9080 2013-04-12 13:57:23Z kozyaikin $
--$Description:
alter table df_bank add SHORT_NAME varchar(200);