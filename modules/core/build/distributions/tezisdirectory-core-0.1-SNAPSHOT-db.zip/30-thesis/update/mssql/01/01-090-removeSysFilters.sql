--$Id: 01-090-removeSysFilters.sql 5034 2012-05-18 07:34:48Z shishov $

delete from SEC_FILTER where NAME = 'По участию в процессе и состоянию'^