--$Id: 130422-1336-updateStartIfFaild.sql 9301 2013-04-22 09:58:57Z kozyaikin $
--$Description:
UPDATE TM_SCHEDULE_TASK set START_IF_FAILED=1^