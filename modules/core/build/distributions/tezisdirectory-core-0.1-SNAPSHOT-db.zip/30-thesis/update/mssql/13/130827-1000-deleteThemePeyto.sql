-- $Id: 130827-1000-deleteThemePeyto.sql 11488 2013-08-27 06:00:52Z gaponenkov $
-- Description:

delete from sec_user_setting where value = 'peyto'