-- $Id$

alter table DF_DOC_TYPE add FIELDS_XML varchar(max);
