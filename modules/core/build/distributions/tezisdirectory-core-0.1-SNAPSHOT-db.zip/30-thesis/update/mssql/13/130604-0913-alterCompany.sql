--$Id: 130604-0913-alterCompany.sql 10089 2013-06-04 05:21:07Z kozyaikin $
--Description:
alter table DF_COMPANY alter column FULL_NAME varchar(400)^