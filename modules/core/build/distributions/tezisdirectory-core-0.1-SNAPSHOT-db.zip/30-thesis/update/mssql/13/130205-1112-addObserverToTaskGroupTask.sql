
alter table TM_TASK_GROUP_TASK add OBSERVER_ID uniqueidentifier;