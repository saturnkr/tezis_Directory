-- $Id: 121210-addAddressInBank.sql 7180 2012-12-19 13:44:43Z murzin $
-- Description:
alter table DF_BANK add ADDRESS varchar(300);