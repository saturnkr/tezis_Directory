--$Id: 130426-0920-updateUseWorkCalendar.sql 9542 2013-05-08 09:42:49Z kozyaikin $
--$Description:
update TM_SCHEDULE_TRIGGER set USE_WORK_CALENDAR=0;