-- $Id: 130821-1039-docKindPublishPortal.sql 12498 2013-10-14 07:46:44Z gorbunkov $
alter table DF_DOC_KIND add PORTAL_PUBLISH_ALLOWED tinyint;