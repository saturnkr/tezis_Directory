
alter table DF_DOC add IMPORTED tinyint^
update DF_DOC set IMPORTED = 0;