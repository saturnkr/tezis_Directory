--$Id: 130416-1737-addColumnToTaskGroup.sql 9412 2013-04-27 09:08:27Z pavlov $
--Description:
alter table TM_TASK_GROUP add DISCUSSED varchar(400)^