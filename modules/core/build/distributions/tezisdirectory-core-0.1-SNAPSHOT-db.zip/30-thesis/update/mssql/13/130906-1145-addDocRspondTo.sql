-- $Id: 130906-1145-addDocRspondTo.sql 11848 2013-09-16 15:49:35Z saiyan $
-- Description:

alter table DF_DOC add RESPOND_TO datetime;
alter table DF_DOC add RESPOND_REGISTRATION_DATE datetime;

