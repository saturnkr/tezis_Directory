-- $Id$

alter table DF_DOC alter column COMMENT varchar(max);