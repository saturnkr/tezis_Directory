
alter table TM_PROJECT add TYPE varchar(1)^
update TM_PROJECT set TYPE = 'P'^