--$Id: 130425-1821-addUseWorkCalendarToScheduleTrigger.sql 9390 2013-04-26 08:30:15Z kozyaikin $
--$Description:
alter table TM_SCHEDULE_TRIGGER add USE_WORK_CALENDAR tinyint;