-- $Id$

insert into SEC_USER (ID, CREATE_TS, VERSION, LOGIN, LOGIN_LC, PASSWORD, NAME, GROUP_ID, ACTIVE)
values ('b18e3c10-0328-11e2-969a-fb0e8fd8c622', CURRENT_TIMESTAMP, 0, 'system', 'system', '6a9e40c1c2439a85035943bda146d965', 'System user', '0fa2b1a5-1d68-4d69-9fbd-dff348347f93', 1)^
