-- $Id$:
-- Description:
alter table DF_DOC add THEME varchar(255)^