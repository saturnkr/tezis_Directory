--$Id: 01-070-updateSecUserDescr.sql 5027 2012-05-17 15:51:35Z shishov $

update SEC_USER set TYPE = 'T'^