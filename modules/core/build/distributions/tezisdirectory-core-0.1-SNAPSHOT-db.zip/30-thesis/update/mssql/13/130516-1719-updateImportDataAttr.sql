--$Id:$
--$Description

--insert INTO df_import_data_attr(id, create_ts, created_by, import_data_type_id, cell_name, property_name, field_type)
--values (newId(), current_timestamp, 'admin', '33433e50-a38c-11e2-9506-a71c3d8f3fe2', 'Валюта', 'currency', 'df$Currency');
