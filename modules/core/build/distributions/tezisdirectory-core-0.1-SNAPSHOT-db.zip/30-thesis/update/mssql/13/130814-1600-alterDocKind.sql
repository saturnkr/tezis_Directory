-- $Id: 130814-1600-alterDocKind.sql 11302 2013-08-14 12:03:28Z chernov $

alter table DF_DOC_KIND alter column FIELDS_XML varchar(max);