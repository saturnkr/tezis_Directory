--$Id$--
alter table REPORT_TEMPLATE add column OUTPUT_NAME_PATTERN varchar2(255);

