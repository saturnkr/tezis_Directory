--$Id$--
alter table REPORT_REPORT add column XML clob^
alter table REPORT_TEMPLATE add column CONTENT blob^
alter table REPORT_TEMPLATE add column NAME varchar2(500)^

