--$Id$--

alter table REPORT_TEMPLATE add column CUSTOM_DEFINED_BY integer default 100;
