--$Id$--

alter table REPORT_REPORT alter column REPORT_TYPE integer null;
alter table REPORT_TEMPLATE alter column TEMPLATE_FILE_ID uniqueidentifier null;
