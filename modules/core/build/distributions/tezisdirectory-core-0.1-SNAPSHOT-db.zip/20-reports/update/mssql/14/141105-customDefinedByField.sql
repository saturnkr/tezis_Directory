--$Id$--

alter table REPORT_TEMPLATE add CUSTOM_DEFINED_BY integer default 100;
