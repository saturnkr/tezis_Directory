--$Id$--

{call sp_rename 'REPORT_DATA_SET.TYPE', 'DATA_SET_TYPE', 'column'};

{call sp_rename 'REPORT_INPUT_PARAMETER.TYPE', 'PARAMETER_TYPE', 'column'};