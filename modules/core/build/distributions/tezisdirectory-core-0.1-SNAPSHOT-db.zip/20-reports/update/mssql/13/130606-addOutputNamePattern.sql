--$Id$--
alter table REPORT_TEMPLATE add OUTPUT_NAME_PATTERN varchar(255);

