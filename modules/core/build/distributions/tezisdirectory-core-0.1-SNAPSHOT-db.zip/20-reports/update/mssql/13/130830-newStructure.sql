--$Id$--
alter table REPORT_REPORT add XML varchar(max)^
alter table REPORT_TEMPLATE add CONTENT image^
alter table REPORT_TEMPLATE add NAME varchar(500)^

