--$Id$--

alter table REPORT_DATA_SET rename column TYPE to DATA_SET_TYPE;
alter table REPORT_INPUT_PARAMETER rename column TYPE to PARAMETER_TYPE;