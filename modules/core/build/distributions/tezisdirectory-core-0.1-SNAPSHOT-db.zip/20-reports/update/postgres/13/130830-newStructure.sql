--$Id$--
alter table REPORT_REPORT add column XML text^
alter table REPORT_TEMPLATE add column CONTENT bytea^
alter table REPORT_TEMPLATE add column NAME varchar(500)^

