--$Id$--

alter table REPORT_REPORT alter column REPORT_TYPE drop not null;
alter table REPORT_TEMPLATE alter column TEMPLATE_FILE_ID drop not null;
