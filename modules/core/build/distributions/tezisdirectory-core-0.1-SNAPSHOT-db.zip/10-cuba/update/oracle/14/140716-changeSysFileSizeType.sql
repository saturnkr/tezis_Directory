-- $Id$
-- Description: Change type of column FILE_SIZE in SYS_FILE table

alter table SYS_FILE modify (FILE_SIZE number(19))^