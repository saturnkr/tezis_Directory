--$Id$

alter table SEC_USER add column TYPE varchar(1)^

update SEC_USER set TYPE = 'C'^