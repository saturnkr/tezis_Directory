-- $Id$
alter table SYS_CATEGORY_ATTR add column DEFAULT_DATE_IS_CURRENT boolean;