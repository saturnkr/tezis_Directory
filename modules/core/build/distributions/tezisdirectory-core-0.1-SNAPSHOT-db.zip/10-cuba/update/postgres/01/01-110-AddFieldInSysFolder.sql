-- $Id$
-- Description: adding field in SYS_FOLDER

alter table SYS_FOLDER  add column DOUBLE_NAME varchar(100);