-- $Id$
-- Description:
ALTER TABLE SEC_SCREEN_HISTORY ALTER column URL type TEXT;