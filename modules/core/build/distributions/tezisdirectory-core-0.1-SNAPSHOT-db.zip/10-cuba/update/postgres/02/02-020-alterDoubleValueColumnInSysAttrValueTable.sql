-- $Id$
-- Description:
alter table SYS_ATTR_VALUE alter column DOUBLE_VALUE type numeric;
alter table SYS_CATEGORY_ATTR alter column DEFAULT_DOUBLE type numeric;