-- $Id$
-- Description: change type of script columns
ALTER TABLE sys_app_folder ALTER COLUMN visibility_script TYPE text;
ALTER TABLE sys_app_folder ALTER COLUMN quantity_script TYPE text;