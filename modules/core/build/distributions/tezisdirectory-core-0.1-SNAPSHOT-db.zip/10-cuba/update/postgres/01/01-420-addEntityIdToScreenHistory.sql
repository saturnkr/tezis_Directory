-- $Id$

alter table SEC_SCREEN_HISTORY add ENTITY_ID uuid;