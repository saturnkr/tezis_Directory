--$Id$
-- Description: add code field to CategoryAttribute

alter table SYS_CATEGORY_ATTR add column CODE varchar(50);