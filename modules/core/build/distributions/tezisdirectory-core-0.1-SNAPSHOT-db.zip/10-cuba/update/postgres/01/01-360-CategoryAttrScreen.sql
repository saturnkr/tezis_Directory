--$Id$

alter table SYS_CATEGORY_ATTR add SCREEN varchar(255);