-- $Id$
-- Description:

alter table SEC_USER_SUBSTITUTION add column START_DATE timestamp;