-- $Id$
-- Description: Rename double_name column to tab_name
ALTER TABLE sys_folder RENAME COLUMN double_name to tab_name;