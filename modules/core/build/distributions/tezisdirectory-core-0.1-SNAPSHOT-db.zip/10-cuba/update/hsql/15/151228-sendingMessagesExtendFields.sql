--$Id$
alter table SYS_SENDING_MESSAGE alter column ADDRESS_TO longvarchar^
alter table SYS_SENDING_MESSAGE alter column ATTACHMENTS_NAME longvarchar^

