-- $Id$
-- Description: Adding WF_ASSIGNMENT.ITERATION field

alter table WF_ASSIGNMENT add ITERATION integer;

