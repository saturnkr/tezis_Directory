-- $Id$
-- Description:

update WF_PROC set COMBINED_STAGES_ENABLED = false where COMBINED_STAGES_ENABLED is NULL;