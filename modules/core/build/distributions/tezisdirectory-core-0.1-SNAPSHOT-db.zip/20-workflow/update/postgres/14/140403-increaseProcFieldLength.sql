--$Id$

alter table WF_PROC alter column STATES type varchar(1500) ^