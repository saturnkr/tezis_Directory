-- $Id$

alter table WF_ASSIGNMENT alter COMMENT type text;