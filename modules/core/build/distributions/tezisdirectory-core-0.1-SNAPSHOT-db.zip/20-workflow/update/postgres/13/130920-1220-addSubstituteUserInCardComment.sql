-- $Id$
-- Description:

alter table WF_CARD_COMMENT add SUBSTITUTE_USER_ID uuid^