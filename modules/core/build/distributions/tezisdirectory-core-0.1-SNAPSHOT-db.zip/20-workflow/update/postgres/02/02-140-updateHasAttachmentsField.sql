-- $Id$
-- Description:

update WF_CARD set HAS_ATTACHMENTS = false where HAS_ATTACHMENTS is NULL;