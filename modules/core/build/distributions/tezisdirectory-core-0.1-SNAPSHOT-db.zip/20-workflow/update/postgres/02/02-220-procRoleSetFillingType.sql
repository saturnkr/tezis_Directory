-- $Id$
update WF_PROC_ROLE set ORDER_FILLING_TYPE = 'P' where ORDER_FILLING_TYPE is null;