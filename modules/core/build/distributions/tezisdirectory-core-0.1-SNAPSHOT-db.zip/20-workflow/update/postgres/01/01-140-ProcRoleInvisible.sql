-- $Id$
-- Description: create INVISIBLE column in WF_PROC_ROLE table

alter table WF_PROC_ROLE add INVISIBLE boolean;