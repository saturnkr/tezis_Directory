-- $Id$
-- Description:

alter table WF_CARD_INFO alter DESCRIPTION type text;
alter table WF_CARD_COMMENT alter COMMENT type text;