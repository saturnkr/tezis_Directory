-- $Id$
-- Description:

alter table WF_PROC_STAGE
    add DURATION_SCRIPT_ENABLED boolean,
    add DURATION_SCRIPT text;