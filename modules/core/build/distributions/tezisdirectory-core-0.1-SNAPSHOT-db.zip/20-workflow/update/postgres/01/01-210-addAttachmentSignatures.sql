-- $Id$
-- Description: adding WF_ATTACHMENT.SIGNATURES

alter table WF_ATTACHMENT add SIGNATURES text;
