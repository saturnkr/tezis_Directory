--$Id$
alter table WF_DESIGN add column DESIGN_TYPE varchar(50);