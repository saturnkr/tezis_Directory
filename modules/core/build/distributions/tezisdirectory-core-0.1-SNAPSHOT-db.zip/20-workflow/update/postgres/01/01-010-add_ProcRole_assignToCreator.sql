-- $Id$
-- Description: add WF_PROC_ROLE.ASSIGN_TO_CREATOR field

alter table WF_PROC_ROLE add ASSIGN_TO_CREATOR boolean;
