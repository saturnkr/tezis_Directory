-- $Id$
-- Description:

alter table WF_PROC add COMBINED_STAGES_ENABLED boolean;