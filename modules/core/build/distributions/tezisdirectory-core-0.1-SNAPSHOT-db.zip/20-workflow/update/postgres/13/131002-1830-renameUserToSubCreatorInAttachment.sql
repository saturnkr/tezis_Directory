--$Id$
--$Description: renames USER_ID column

alter table WF_ATTACHMENT rename column USER_ID to SUBSTITUTED_CREATOR_ID ^