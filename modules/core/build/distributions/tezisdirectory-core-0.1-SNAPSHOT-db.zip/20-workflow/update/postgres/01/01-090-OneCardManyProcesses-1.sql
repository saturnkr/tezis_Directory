-- $Id$
-- Description: One Card - Many Processes enhancement (continues)

alter table WF_CARD_PROC add START_COUNT integer
^
alter table WF_CARD_PROC add STATE varchar(255)
^
