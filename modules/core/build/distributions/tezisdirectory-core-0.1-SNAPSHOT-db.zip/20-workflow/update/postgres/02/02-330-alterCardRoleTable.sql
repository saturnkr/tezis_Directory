-- $Id$
alter table WF_CARD_ROLE
    add column DURATION integer,
    add column TIME_UNIT varchar(1);
