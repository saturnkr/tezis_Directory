-- $Id$
-- Description:

alter table WF_PROC alter column STATES type varchar(3000)^