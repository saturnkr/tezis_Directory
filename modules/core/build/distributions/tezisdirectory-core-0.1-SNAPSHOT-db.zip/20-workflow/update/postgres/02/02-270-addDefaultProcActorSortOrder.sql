--$Id$

alter table WF_DEFAULT_PROC_ACTOR add column SORT_ORDER integer^