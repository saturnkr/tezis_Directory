-- $Id$
-- Description: add column WF_CARD_ROLE.SORT_ORDER

alter table WF_CARD_ROLE add SORT_ORDER integer;