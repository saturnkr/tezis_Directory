-- $Id$
-- Description: add comment to attachment

alter table WF_ATTACHMENT add COMMENT varchar(1000);