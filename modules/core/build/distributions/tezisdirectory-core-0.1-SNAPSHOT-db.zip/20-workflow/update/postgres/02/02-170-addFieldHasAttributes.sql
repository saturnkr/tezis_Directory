-- $Id$
-- Description: add field HAS_ATTRIBUTES to WF_CARD

alter table WF_CARD add column HAS_ATTRIBUTES boolean^