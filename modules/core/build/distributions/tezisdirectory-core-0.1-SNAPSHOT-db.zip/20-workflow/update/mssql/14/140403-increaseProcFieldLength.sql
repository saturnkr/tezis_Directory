--$Id$

alter table wf_proc alter column states varchar(1500) ^