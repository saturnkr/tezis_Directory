--$Id$

alter table WF_PROC_APP_FOLDER alter column FOLDER_ID uniqueidentifier not null^
alter table WF_PROC_APP_FOLDER add primary key (FOLDER_ID);