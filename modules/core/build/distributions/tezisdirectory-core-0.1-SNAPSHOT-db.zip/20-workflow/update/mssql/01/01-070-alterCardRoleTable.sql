-- $Id$
alter table WF_CARD_ROLE add DURATION integer;
alter table WF_CARD_ROLE add TIME_UNIT varchar(1);
