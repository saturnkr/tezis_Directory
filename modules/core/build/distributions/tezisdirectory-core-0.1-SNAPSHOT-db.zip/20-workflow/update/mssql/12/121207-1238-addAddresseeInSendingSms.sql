--$Id$
--Description:
ALTER TABLE WF_SENDING_SMS ADD ADDRESSEE varchar(200)^