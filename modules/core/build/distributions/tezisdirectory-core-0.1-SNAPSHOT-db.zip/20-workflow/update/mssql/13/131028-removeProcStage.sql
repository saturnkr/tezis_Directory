--$Id$

drop table WF_PROC_STAGE_PROC_ROLE;
drop table WF_CARD_STAGE;
drop table WF_PROC_STAGE;
drop table WF_PROC_STAGE_TYPE;
