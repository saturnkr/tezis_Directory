-- $Id$

drop table WF_PROC_ROLE_PERMISSION;