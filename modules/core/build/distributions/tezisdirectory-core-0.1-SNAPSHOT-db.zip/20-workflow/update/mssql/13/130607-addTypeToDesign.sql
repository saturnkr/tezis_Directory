--$Id$
--$Description : missing scripts for ms sql

alter table WF_DESIGN add DESIGN_TYPE varchar(50);