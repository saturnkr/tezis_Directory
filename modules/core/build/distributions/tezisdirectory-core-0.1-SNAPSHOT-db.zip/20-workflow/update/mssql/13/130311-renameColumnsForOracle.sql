--$Id$

{call sp_rename 'WF_ASSIGNMENT.COMMENT', 'ASSIGNMENT_COMMENT', 'column'};

{call sp_rename 'WF_ATTACHMENT.TYPE', 'ATTACHMENT_TYPE', 'column'};

{call sp_rename 'WF_ATTACHMENT.COMMENT', 'ATTACHMENT_COMMENT', 'column'};

{call sp_rename 'WF_ATTACHMENTTYPE.COMMENT', 'ATTACHMENTTYPE_COMMENT', 'column'};

{call sp_rename 'WF_CALENDAR.COMMENT', 'CALENDAR_COMMENT', 'column'};

{call sp_rename 'WF_CARD.TYPE', 'CARD_TYPE', 'column'};

{call sp_rename 'WF_CARD_COMMENT.COMMENT', 'CARD_COMMENT', 'column'};

{call sp_rename 'WF_CARD_INFO.TYPE', 'CARD_INFO_TYPE', 'column'};

{call sp_rename 'WF_DESIGN_FILE.TYPE', 'DESIGN_FILE_TYPE', 'column'};

{call sp_rename 'WF_PROC_ROLE_PERMISSION.TYPE', 'PERMISSION_TYPE', 'column'};