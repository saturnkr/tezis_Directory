--$Id$
alter table WF_CARD_PROC add JBPM_PROCESS_ID varchar(255)^