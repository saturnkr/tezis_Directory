--$Id: 01-010-addDefaultProcActorSortOrder.sql 7714 2012-04-26 09:38:26Z shishov $

alter table WF_DEFAULT_PROC_ACTOR add SORT_ORDER integer^