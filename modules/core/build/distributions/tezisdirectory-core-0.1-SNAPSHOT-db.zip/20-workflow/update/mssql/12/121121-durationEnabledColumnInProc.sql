-- $Id$

alter table WF_PROC add DURATION_ENABLED tinyint^