-- $Id$

alter table WF_CARD add PARENT_CARD_ACCESS char(1)^
update WF_CARD set PARENT_CARD_ACCESS = 0^