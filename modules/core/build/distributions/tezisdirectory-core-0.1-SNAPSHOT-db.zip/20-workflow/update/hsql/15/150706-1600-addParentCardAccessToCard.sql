-- $Id$

alter table WF_CARD add PARENT_CARD_ACCESS boolean^
update WF_CARD set PARENT_CARD_ACCESS = false^