--$Id$

alter table WF_CALENDAR drop column WORK_DAY_OF_WEEK^
alter table WF_CALENDAR add WORK_DAY_OF_WEEK numeric(1)^
